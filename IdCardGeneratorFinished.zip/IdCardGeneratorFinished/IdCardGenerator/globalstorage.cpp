#include "GlobalStorage.h"
#include <QVector>

QVector<Student> GlobalStorage::studentsVector; // Initialize vectors
QVector<Faculty> GlobalStorage::facultyVector;
