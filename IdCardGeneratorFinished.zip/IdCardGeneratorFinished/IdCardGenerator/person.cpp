#include "person.h"

Person::Person() : User() {} // Constructor

Person::~Person() {} // Virtual destructor

