#include "user.h"

User::User() : fullName("") {} // Constructor

User::~User() {} // Virtual destructor

